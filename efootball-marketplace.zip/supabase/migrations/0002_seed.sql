-- Équipes de démonstration (remplacez logo_url/cover_url par vos assets dans storage.team-images)
insert into teams (name, description, category, price_points, is_featured, logo_url, cover_url) values
('Real Madrid CF', 'Le club royal, recordman de la Ligue des Champions.', 'European Clubs', 1500, true,
 'https://upload.wikimedia.org/wikipedia/en/5/56/Real_Madrid_CF.svg',
 'https://images.unsplash.com/photo-1522778119026-d647f0596c20'),
('FC Barcelona', 'Le style blaugrana, la Masia, le Camp Nou.', 'European Clubs', 1400, true,
 'https://upload.wikimedia.org/wikipedia/en/4/47/FC_Barcelona_%28crest%29.svg',
 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2'),
('Paris Saint-Germain', 'La capitale du football français.', 'European Clubs', 1200, false,
 'https://upload.wikimedia.org/wikipedia/en/a/a7/Paris_Saint-Germain_F.C..svg',
 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55'),
('France 1998', 'Les Bleus champions du monde, génération Zidane.', 'Legendary Teams', 2500, true,
 null, 'https://images.unsplash.com/photo-1526232761682-d26e03ac148e'),
('Brazil 2002', 'La Seleção triomphale, 3 étoiles et le football-jogo.', 'National Teams', 2200, false,
 null, 'https://images.unsplash.com/photo-1553778263-73a83bab9b0c'),
('Galaxy All-Stars', 'Collection exclusive : un XI légendaire hors du temps.', 'Exclusive Collections', 5000, true,
 null, 'https://images.unsplash.com/photo-1508357941501-0924cf312bbd'),
('Street Kings FC', 'Équipe spéciale street football, style urbain.', 'Special Teams', 800, false,
 null, 'https://images.unsplash.com/photo-1459865264687-595d652de67e'),
('Germany 2014', 'Mannschaft championne du monde au Brésil.', 'National Teams', 1800, false,
 null, 'https://images.unsplash.com/photo-1574629810360-7efbbe195018');

insert into rewards (title, description, points_reward, kind) values
('Connexion quotidienne', 'Revenez chaque jour pour gagner des points.', 100, 'daily'),
('Bienvenue', 'Récompense de bienvenue — une seule fois.', 500, 'mission'),
('Compléter son profil', 'Ajoutez un avatar et un pseudo.', 200, 'mission');
