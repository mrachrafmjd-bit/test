-- ============ eFootball Marketplace — Schéma initial ============
create extension if not exists pgcrypto;

-- ---------- Tables ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  avatar_url text,
  is_admin boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.points_accounts (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  balance bigint not null default 0 check (balance >= 0)
);

create table public.teams (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  logo_url text,
  cover_url text,
  description text,
  category text not null check (category in
    ('European Clubs','National Teams','Legendary Teams','Special Teams','Exclusive Collections')),
  price_points bigint not null check (price_points >= 0),
  is_published boolean not null default true,
  is_featured boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.owned_teams (
  user_id uuid not null references public.profiles(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  purchased_at timestamptz not null default now(),
  price_paid bigint not null check (price_paid >= 0),
  primary key (user_id, team_id)
);

create table public.point_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  delta bigint not null,
  reason text not null,
  ref_type text,
  ref_id text,
  created_at timestamptz not null default now()
);

create table public.rewards (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  points_reward bigint not null check (points_reward > 0),
  kind text not null default 'mission' check (kind in ('daily','mission','manual')),
  active boolean not null default true
);

create table public.reward_claims (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  reward_id uuid not null references public.rewards(id) on delete cascade,
  claimed_at timestamptz not null default now(),
  unique (user_id, reward_id, (claimed_at::date))
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  action text not null,
  target text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ---------- Profil + compte de points à l'inscription ----------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, username, avatar_url)
  values (new.id,
          coalesce(new.raw_user_meta_data->>'user_name', new.raw_user_meta_data->>'name',
                   split_part(coalesce(new.email,'user'),'@',1)),
          new.raw_user_meta_data->>'avatar_url')
  on conflict (id) do nothing;
  insert into public.points_accounts (user_id) values (new.id) on conflict do nothing;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

-- ---------- Achat atomique d'une équipe (côté serveur uniquement) ----------
create or replace function public.purchase_team(p_team_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_user uuid := auth.uid();
  v_team teams%rowtype;
  v_balance bigint;
begin
  if v_user is null then raise exception 'AUTH_REQUIRED'; end if;

  select * into v_team from teams
   where id = p_team_id for update;               -- verrou ligne équipe

  if not found then raise exception 'TEAM_NOT_FOUND'; end if;
  if not v_team.is_published then raise exception 'TEAM_UNAVAILABLE'; end if;

  if exists (select 1 from owned_teams where user_id = v_user and team_id = p_team_id) then
    raise exception 'ALREADY_OWNED';
  end if;

  select balance into v_balance from points_accounts
   where user_id = v_user for update;             -- verrou ligne solde
  if not found then raise exception 'ACCOUNT_NOT_FOUND'; end if;

  if v_balance < v_team.price_points then
    raise exception 'INSUFFICIENT_POINTS: il vous faut % points de plus.',
      (v_team.price_points - v_balance);
  end if;

  update points_accounts set balance = balance - v_team.price_points where user_id = v_user;
  insert into owned_teams (user_id, team_id, price_paid) values (v_user, p_team_id, v_team.price_points);
  insert into point_transactions (user_id, delta, reason, ref_type, ref_id)
  values (v_user, -v_team.price_points, 'Achat : ' || v_team.name, 'team', p_team_id::text);
  insert into audit_logs (actor_id, action, target, metadata)
  values (v_user, 'purchase_team', p_team_id::text, jsonb_build_object('price', v_team.price_points));

  return jsonb_build_object('ok', true, 'balance', v_balance - v_team.price_points);
end $$;

-- ---------- Récompense / mission ----------
create or replace function public.claim_reward(p_reward_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_user uuid := auth.uid();
  v_reward rewards%rowtype;
  v_today date := now()::date;
begin
  if v_user is null then raise exception 'AUTH_REQUIRED'; end if;
  select * into v_reward from rewards where id = p_reward_id and active;
  if not found then raise exception 'REWARD_NOT_FOUND'; end if;
  if v_reward.kind <> 'manual' then
    if exists (select 1 from reward_claims
                where user_id = v_user and reward_id = p_reward_id
                  and claimed_at::date = v_today) then
      raise exception 'ALREADY_CLAIMED';
    end if;
    insert into reward_claims (user_id, reward_id) values (v_user, p_reward_id);
  end if;
  update points_accounts set balance = balance + v_reward.points_reward where user_id = v_user;
  insert into point_transactions (user_id, delta, reason, ref_type, ref_id)
  values (v_user, v_reward.points_reward, 'Récompense : ' || v_reward.title, 'reward', p_reward_id::text);
  return jsonb_build_object('ok', true);
end $$;

-- ---------- Attribution / retrait de points par un admin ----------
create or replace function public.award_points(p_user_id uuid, p_delta bigint, p_reason text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_admin uuid := auth.uid();
begin
  if v_admin is null or not exists (select 1 from profiles where id = v_admin and is_admin) then
    raise exception 'FORBIDDEN';
  end if;
  if p_delta < 0 then
    if (select balance from points_accounts where user_id = p_user_id) < -p_delta then
      raise exception 'BALANCE_WOULD_GO_NEGATIVE';
    end if;
  end if;
  update points_accounts set balance = balance + p_delta where user_id = p_user_id;
  insert into point_transactions (user_id, delta, reason, ref_type) values (p_user_id, p_delta, p_reason, 'admin');
  insert into audit_logs (actor_id, action, target, metadata)
  values (v_admin, 'award_points', p_user_id::text, jsonb_build_object('delta', p_delta, 'reason', p_reason));
  return jsonb_build_object('ok', true);
end $$;

-- ---------- Storage : bucket public team-images ----------
insert into storage.buckets (id, name, public) values ('team-images','team-images', true)
on conflict (id) do nothing;
create policy "public read" on storage.objects for select using (bucket_id = 'team-images');
create policy "auth upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'team-images');

-- ---------- RLS ----------
create or replace function public.is_admin() returns boolean language sql stable as
$$ select coalesce((select is_admin from profiles where id = auth.uid()), false) $$;

alter table profiles enable row level security;
create policy "public read profiles" on profiles for select using (true);
create policy "self update username/avatar" on profiles for update
  using (auth.uid() = id) with check (auth.uid() = id and is_admin = (select is_admin from profiles where id = auth.uid()));

alter table points_accounts enable row level security;
create policy "self read balance" on points_accounts for select using (auth.uid() = user_id);

alter table teams enable row level security;
create policy "public read published" on teams for select using (is_published or is_admin());
create policy "admin write teams" on teams for all
  using (is_admin()) with check (is_admin());

alter table owned_teams enable row level security;
create policy "owner read owned" on owned_teams for select using (auth.uid() = user_id);

alter table point_transactions enable row level security;
create policy "owner read tx" on point_transactions for select using (auth.uid() = user_id);

alter table rewards enable row level security;
create policy "public read rewards" on rewards for select using (true);
create policy "admin write rewards" on rewards for all using (is_admin()) with check (is_admin());

alter table reward_claims enable row level security;
create policy "self read claims" on reward_claims for select using (auth.uid() = user_id);

alter table audit_logs enable row level security;
create policy "admin read audit" on audit_logs for select using (is_admin());
