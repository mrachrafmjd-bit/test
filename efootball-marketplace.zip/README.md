# eFootball Team Marketplace

Plateforme full-stack (Next.js 14 App Router + TypeScript + Tailwind CSS + Supabase) :
inscription OAuth (Google/Discord), points internes, marketplace d'équipes, achat atomique côté serveur,
collection "My Teams", récompenses, dashboard utilisateur et panel admin.

> Les équipes achetées restent dans votre collection **sur ce site uniquement** — aucun transfert vers le jeu eFootball officiel.

## 1. Prérequis
- Node.js 18+
- Un projet Supabase (https://supabase.com)

## 2. Configuration Supabase

### 2.1 Base de données
Dans le SQL Editor de Supabase, exécutez **dans l'ordre** :
1. `supabase/migrations/0001_init.sql` — tables, RLS, fonctions `purchase_team`, `award_points`, `claim_reward`, audit.
2. `supabase/migrations/0002_seed.sql` — équipes de démonstration + récompenses (optionnel mais recommandé).

### 2.2 Storage
Créez un bucket public `team-images` (Storage → New bucket → Public).
La politique SQL de lecture/insertion est incluse dans `0001_init.sql`.

### 2.3 Authentification (Dashboard → Authentication → Providers)
- **Google** : Google Cloud Console → APIs & Services → Credentials → OAuth 2.0 Client ID (Web).
  - Authorized redirect URI : `https://<votre-projet>.supabase.co/auth/v1/callback`
  - Copiez `Client ID` / `Client Secret` dans Supabase.
- **Discord** : Discord Developer Portal → New Application → OAuth2.
  - Redirect URI : `https://<votre-projet>.supabase.co/auth/v1/callback`
  - Copiez `Client ID` / `Client Secret` dans Supabase.
- **Kick** : aucune intégration OAuth standardisée grand public n'est documentée à ce jour.
  Si vous obtenez des identifiants OAuth officiels, ajoutez-les via *Authentication → Providers → Add Provider (Custom/OAuth)*.
  Tant que ce n'est pas configuré, la plateforme ne prétend pas le supporter : aucun bouton Kick n'apparaît.

### 2.4 Site URL
Authentication → URL Configuration → Site URL : `http://localhost:3000` (dev),
puis votre domaine de production. Les URLs de redirection sont gérées par `src/app/auth/callback/route.ts`.

## 3. Variables d'environnement

```bash
cp .env.example .env.local
```
Remplissez avec les valeurs de Supabase (Settings → API) :
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

## 4. Lancer en local

```bash
npm install
npm run dev
```

## 5. Déploiement
- Vercel : importez le repo, ajoutez les variables d'environnement, mettez à jour le Site URL Supabase.
- Notez que `npm run build` doit être exécuté dans un environnement avec les variables d'env — les pages sont dynamiques.

## 6. Devenir administrateur
Après inscription, dans Supabase SQL Editor :
```sql
update profiles set is_admin = true where username = 'votre_pseudo';
```
