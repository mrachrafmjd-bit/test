import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        night: "#070B14", navy: "#0B1220", panel: "#101A2E",
        electric: "#2F7DFF", electricDark: "#1E5FD6"
      },
      animation: { "fade-up": "fadeUp .6s ease both", "pulse-glow": "pulseGlow 2.5s ease-in-out infinite" },
      keyframes: {
        fadeUp: { "0%": { opacity: "0", transform: "translateY(16px)" }, "100%": { opacity: "1", transform: "translateY(0)" } },
        pulseGlow: { "0%,100%": { boxShadow: "0 0 20px rgba(47,125,255,.35)" }, "50%": { boxShadow: "0 0 45px rgba(47,125,255,.6)" } }
      }
    }
  },
  plugins: []
} satisfies Config;
