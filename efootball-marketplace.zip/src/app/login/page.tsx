import OAuthButtons from "@/components/OAuthButtons";
import { getUserContext } from "@/lib/data";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function LoginPage({ searchParams }: { searchParams: { mode?: string } }) {
  const { user } = await getUserContext();
  if (user) redirect("/profile");
  return (
    <div className="max-w-md mx-auto card p-8 mt-10 animate-fade-up">
      <h1 className="text-2xl font-extrabold text-center">
        {searchParams.mode === "register" ? "Créer un compte" : "Connexion"}
      </h1>
      <p className="text-sm text-white/50 text-center mt-2 mb-6">
        Connexion sécurisée via OAuth. Aucun mot de passe tiers n'est demandé ni stocké.
      </p>
      <OAuthButtons />
    </div>
  );
}
