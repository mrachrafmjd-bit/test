import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getUserContext } from "@/lib/data";
import { createClient } from "@/lib/supabase/server";
import { TEAM_CATEGORIES, type Team, type PointTransaction } from "@/types/database";

export const dynamic = "force-dynamic";

async function addTeam(formData: FormData) {
  "use server";
  const supabase = createClient();
  const { error } = await supabase.from("teams").insert({
    name: String(formData.get("name")),
    description: String(formData.get("description") || ""),
    category: String(formData.get("category")),
    price_points: Number(formData.get("price")),
    logo_url: String(formData.get("logo") || "") || null,
    cover_url: String(formData.get("cover") || "") || null,
    is_featured: formData.get("featured") === "on",
    is_published: true
  });
  if (error) throw new Error(error.message);
  revalidatePath("/marketplace");
}

async function togglePublish(formData: FormData) {
  "use server";
  const supabase = createClient();
  await supabase.from("teams").update({ is_published: formData.get("publish") === "on" })
    .eq("id", String(formData.get("id")));
  revalidatePath("/marketplace");
}

async function awardPoints(formData: FormData) {
  "use server";
  const supabase = createClient();
  const { error } = await supabase.rpc("award_points", {
    p_user_id: String(formData.get("user_id")),
    p_delta: Number(formData.get("delta")),
    p_reason: String(formData.get("reason"))
  });
  if (error) throw new Error(error.message);
  revalidatePath("/admin");
}

export default async function Admin() {
  const { user, profile } = await getUserContext();
  if (!user || !profile?.is_admin) redirect("/");

  const supabase = createClient();
  const [{ data: teams }, { data: tx }] = await Promise.all([
    supabase.from("teams").select("*").order("created_at", { ascending: false }),
    supabase.from("point_transactions").select("*").order("created_at", { ascending: false }).limit(20)
  ]);

  return (
    <div className="space-y-10">
      <h1 className="text-3xl font-extrabold">Admin <span className="text-amber-400">Dashboard</span></h1>

      <section className="card p-6">
        <h2 className="font-bold mb-4">Ajouter une équipe</h2>
        <form action={addTeam} className="grid sm:grid-cols-2 gap-3">
          <input name="name" required placeholder="Nom de l'équipe" className="input" />
          <select name="category" className="input">{TEAM_CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
          <input name="price" type="number" min="0" required placeholder="Prix (points)" className="input" />
          <input name="logo" placeholder="URL logo (ou storage team-images)" className="input" />
          <input name="cover" placeholder="URL cover image" className="input" />
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="featured" /> Featured</label>
          <textarea name="description" placeholder="Description" className="input sm:col-span-2" rows={2} />
          <button className="btn-primary sm:col-span-2 w-fit">Publier l'équipe</button>
        </form>
      </section>

      <section className="card p-6">
        <h2 className="font-bold mb-4">Gérer les équipes ({teams?.length ?? 0})</h2>
        <div className="divide-y divide-white/10">
          {(teams ?? []).map((t: Team) => (
            <form key={t.id} action={togglePublish} className="py-3 flex flex-wrap items-center gap-3 text-sm">
              <input type="hidden" name="id" value={t.id} />
              <span className="font-semibold flex-1">{t.name}</span>
              <span className="badge">{t.category}</span>
              <span className="text-electric font-bold">⚡ {t.price_points.toLocaleString("fr-FR")}</span>
              <label className="flex items-center gap-2">
                <input type="checkbox" name="publish" defaultChecked={t.is_published} onChange={(e) => e.target.form?.requestSubmit()} />
                Publiée
              </label>
            </form>
          ))}
        </div>
      </section>

      <section className="card p-6">
        <h2 className="font-bold mb-4">Attribuer / retirer des points</h2>
        <form action={awardPoints} className="grid sm:grid-cols-3 gap-3">
          <input name="user_id" required placeholder="UUID utilisateur" className="input" />
          <input name="delta" type="number" required placeholder="+500 ou -200" className="input" />
          <input name="reason" required placeholder="Raison (enregistrée)" className="input" />
          <button className="btn-primary sm:col-span-3 w-fit">Exécuter (vérifié côté serveur)</button>
        </form>
      </section>

      <section className="card p-6">
        <h2 className="font-bold mb-4">Dernières transactions</h2>
        <div className="divide-y divide-white/10 text-sm">
          {(tx ?? []).map((t: PointTransaction) => (
            <div key={t.id} className="py-2 flex justify-between">
              <span className="truncate">{t.reason} <span className="text-white/30">({t.user_id.slice(0, 8)}…)</span></span>
              <span className={t.delta >= 0 ? "text-emerald-400" : "text-rose-400"}>{t.delta >= 0 ? "+" : ""}{t.delta}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
