import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getUserContext, getMyTeams } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function MyTeams({ searchParams }: { searchParams: { search?: string } }) {
  const { user } = await getUserContext();
  if (!user) redirect("/login");
  const owned = await getMyTeams(searchParams.search);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold">My <span className="text-electric">Teams</span></h1>
          <p className="text-white/50 mt-1">{owned.length} équipe(s) dans votre collection</p>
        </div>
        <form className="flex gap-2">
          <input name="search" defaultValue={searchParams.search} placeholder="Rechercher…" className="input max-w-[16rem]" />
          <button className="btn-ghost text-sm">🔍</button>
        </form>
      </div>
      {owned.length === 0 ? (
        <div className="card p-10 text-center text-white/50">
          <p className="text-4xl mb-3">⚽</p>
          <p>Aucune équipe pour l'instant.</p>
          <Link href="/marketplace" className="btn-primary inline-block mt-5">Explorer le marketplace</Link>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {owned.map((o) => (
            <Link key={o.team_id} href={`/teams/${o.team_id}`} className="card p-5 flex items-center gap-4 animate-fade-up">
              {o.teams?.logo_url ? (
                <Image src={o.teams.logo_url} alt="" width={52} height={52} className="rounded-full bg-white/90 p-1" />
              ) : (
                <div className="w-13 h-13 w-[52px] h-[52px] rounded-full bg-electric/30 border border-electric flex items-center justify-center font-bold">
                  {o.teams?.name.slice(0, 2).toUpperCase()}
                </div>
              )}
              <div className="flex-1">
                <h3 className="font-bold">{o.teams?.name}</h3>
                <p className="text-xs text-white/45">Achetée le {new Date(o.purchased_at).toLocaleDateString("fr-FR")} · ⚡ {o.price_paid.toLocaleString("fr-FR")}</p>
              </div>
              <span className="badge">✓</span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
