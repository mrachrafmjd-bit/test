import Link from "next/link";
import TeamCard from "@/components/TeamCard";
import { getTeams } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [featured, newest] = await Promise.all([
    getTeams({ limit: 3, sort: "price_desc" }),
    getTeams({ limit: 3, sort: "price_asc" })
  ]);
  return (
    <div className="space-y-16">
      {/* Hero */}
      <section className="relative rounded-3xl overflow-hidden border border-white/10 bg-navy py-24 px-6 text-center animate-fade-up">
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_30%_20%,#2F7DFF55,transparent_50%),radial-gradient(circle_at_70%_80%,#2F7DFF33,transparent_50%)]" />
        <h1 className="relative text-4xl sm:text-6xl font-extrabold leading-tight">
          Build Your <span className="text-electric">Ultimate</span> Team Collection
        </h1>
        <p className="relative mt-4 text-white/60 max-w-xl mx-auto">
          Gagnez des points, débloquez des récompenses et collectionnez les plus grandes équipes
          du football dans un marketplace premium.
        </p>
        <div className="relative mt-8 flex gap-4 justify-center">
          <Link href="/login?mode=register" className="btn-primary animate-pulse-glow">Register</Link>
          <Link href="/login" className="btn-ghost">Login</Link>
        </div>
      </section>

      {/* How points work */}
      <section className="grid sm:grid-cols-3 gap-4">
        {[
          ["⚡", "Gagnez des points", "Récompenses quotidiennes, missions et bonus de bienvenue."],
          ["🛒", "Achetez des équipes", "Dépensez vos points sur clubs, nations et collections légendaires."],
          ["🏆", "Collectionnez", "Vos équipes restent à vous, visibles dans My Teams."]
        ].map(([icon, t, d]) => (
          <div key={t} className="card p-6 animate-fade-up">
            <div className="text-3xl">{icon}</div>
            <h3 className="font-bold mt-3">{t}</h3>
            <p className="text-sm text-white/55 mt-1">{d}</p>
          </div>
        ))}
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-5">★ Featured Teams</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {featured.filter((t) => t.is_featured).map((t) => <TeamCard key={t.id} team={t} />)}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-bold mb-5">Newly Added</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {newest.map((t) => <TeamCard key={t.id} team={t} />)}
        </div>
        <div className="text-center mt-8">
          <Link href="/marketplace" className="btn-ghost">Explorer tout le marketplace →</Link>
        </div>
      </section>
    </div>
  );
}
