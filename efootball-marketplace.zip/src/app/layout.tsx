import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = { title: "eFootball Team Marketplace", description: "Build your ultimate team collection." };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <Navbar />
        <main className="max-w-7xl mx-auto px-4 py-8 min-h-[80vh]">{children}</main>
        <footer className="border-t border-white/10 py-6 text-center text-xs text-white/40">
          eFootball Team Marketplace — collection virtuelle, sans transfert vers le jeu officiel.
        </footer>
      </body>
    </html>
  );
}
