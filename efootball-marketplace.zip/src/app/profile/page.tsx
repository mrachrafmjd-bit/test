import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getUserContext, getMyTeams, getTransactions } from "@/lib/data";

export const dynamic = "force-dynamic";

export default async function Profile() {
  const { user, profile, balance } = await getUserContext();
  if (!user) redirect("/login");
  const [teams, transactions] = await Promise.all([getMyTeams(), getTransactions(5)]);

  return (
    <div className="space-y-8">
      <div className="card p-6 flex flex-wrap items-center gap-5 animate-fade-up">
        <div className="w-20 h-20 rounded-full bg-electric/20 border-2 border-electric flex items-center justify-center text-2xl font-extrabold overflow-hidden">
          {profile?.avatar_url ? <Image src={profile.avatar_url} alt="" width={80} height={80} /> : (profile?.username?.slice(0, 2).toUpperCase() ?? "?")}
        </div>
        <div className="flex-1">
          <h1 className="text-2xl font-extrabold">{profile?.username}</h1>
          <p className="text-sm text-white/45">{user.email}</p>
          <p className="text-xs text-white/35 mt-1">Fournisseurs connectés : {user.app_metadata.providers?.join(", ") || "—"}</p>
        </div>
        <div className="flex gap-6 text-center">
          <div><p className="text-2xl font-extrabold text-electric">⚡ {balance.toLocaleString("fr-FR")}</p><p className="text-xs text-white/45">points</p></div>
          <div><p className="text-2xl font-extrabold">{teams.length}</p><p className="text-xs text-white/45">équipes</p></div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <section className="card p-5">
          <h2 className="font-bold mb-4">Achat(s) récent(s)</h2>
          {teams.slice(0, 4).map((o) => (
            <Link key={o.team_id} href={`/teams/${o.team_id}`} className="flex justify-between py-2 border-b border-white/5 text-sm hover:text-electric">
              <span>{o.teams?.name}</span><span className="text-white/40">{new Date(o.purchased_at).toLocaleDateString("fr-FR")}</span>
            </Link>
          ))}
          {teams.length === 0 && <p className="text-sm text-white/40">Aucune équipe — <Link className="text-electric" href="/marketplace">voir le marketplace</Link>.</p>}
        </section>
        <section className="card p-5">
          <h2 className="font-bold mb-4">Transactions récentes</h2>
          {transactions.map((t) => (
            <div key={t.id} className="flex justify-between py-2 border-b border-white/5 text-sm">
              <span className="truncate">{t.reason}</span>
              <span className={t.delta >= 0 ? "text-emerald-400" : "text-rose-400"}>{t.delta >= 0 ? "+" : ""}{t.delta}</span>
            </div>
          ))}
          <Link href="/rewards" className="text-sm text-electric inline-block mt-3">Tout voir →</Link>
        </section>
      </div>
    </div>
  );
}
