import Image from "next/image";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getUserContext } from "@/lib/data";
import PurchaseButton from "@/components/PurchaseButton";
import type { Team, OwnedTeam } from "@/types/database";

export const dynamic = "force-dynamic";

export default async function TeamPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: team } = await supabase.from("teams").select("*").eq("id", params.id).single<Team>();
  if (!team || !team.is_published) notFound();

  const { user, balance } = await getUserContext();
  let owned = false;
  if (user) {
    const { data } = await supabase.from("owned_teams").select("*")
      .eq("user_id", user.id).eq("team_id", team.id).maybeSingle<OwnedTeam>();
    owned = !!data;
  }

  return (
    <div className="card animate-fade-up">
      <div className="relative h-64 bg-navy">
        {team.cover_url && <Image src={team.cover_url} alt="" fill className="object-cover opacity-50" priority />}
        <div className="absolute inset-0 bg-gradient-to-t from-panel via-panel/40 to-transparent" />
        <div className="absolute bottom-6 left-6 flex items-center gap-4">
          {team.logo_url && <Image src={team.logo_url} alt={team.name} width={72} height={72} className="rounded-full bg-white/95 p-1.5" />}
          <div>
            <h1 className="text-3xl font-extrabold">{team.name}</h1>
            <span className="badge mt-1 inline-block">{team.category}</span>
          </div>
        </div>
      </div>
      <div className="p-6 flex flex-col md:flex-row gap-6 md:items-center">
        <p className="text-white/70 flex-1">{team.description}</p>
        <div className="shrink-0">
          {user ? (
            <PurchaseButton team={team} balance={balance} owned={owned} />
          ) : (
            <a href="/login" className="btn-primary inline-block">Connectez-vous pour acheter</a>
          )}
        </div>
      </div>
      <p className="px-6 pb-6 text-xs text-white/35">
        L'équipe rejoint votre collection sur ce site uniquement — aucun transfert vers le jeu eFootball officiel.
      </p>
    </div>
  );
}
