import Link from "next/link";
import TeamCard from "@/components/TeamCard";
import { getTeams } from "@/lib/data";
import { TEAM_CATEGORIES } from "@/types/database";

export const dynamic = "force-dynamic";

export default async function Marketplace({ searchParams }: { searchParams: Record<string, string | undefined> }) {
  const teams = await getTeams({
    category: searchParams.category,
    search: searchParams.search,
    sort: searchParams.sort
  });
  const qs = (k: string, v: string) => {
    const p = new URLSearchParams(searchParams as Record<string, string>);
    p.set(k, v); return `?${p.toString()}`;
  };
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-extrabold">Team <span className="text-electric">Marketplace</span></h1>
      <form className="flex flex-wrap gap-3 items-center">
        <input name="search" defaultValue={searchParams.search} placeholder="Rechercher une équipe…" className="input max-w-xs" />
        <select name="category" defaultValue={searchParams.category ?? ""} className="input max-w-xs">
          <option value="">Toutes catégories</option>
          {TEAM_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select name="sort" defaultValue={searchParams.sort ?? "price_asc"} className="input max-w-[12rem]">
          <option value="price_asc">Prix croissant</option>
          <option value="price_desc">Prix décroissant</option>
        </select>
        <button className="btn-primary">Filtrer</button>
      </form>
      {searchParams.category && (
        <div className="flex gap-2 flex-wrap">
          <span className="text-sm text-white/50">Filtres :</span>
          <Link href={`/marketplace${qs("category", searchParams.category)}`} className="badge">{searchParams.category} ✕</Link>
        </div>
      )}
      <p className="text-sm text-white/40">{teams.length} équipe(s) disponible(s)</p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {teams.map((t) => <TeamCard key={t.id} team={t} />)}
      </div>
    </div>
  );
}
