import { redirect } from "next/navigation";
import { getUserContext, getRewards, getTransactions } from "@/lib/data";
import ClaimButton from "@/components/ClaimButton";

export const dynamic = "force-dynamic";

export default async function Rewards() {
  const { user, balance } = await getUserContext();
  if (!user) redirect("/login");
  const [rewards, transactions] = await Promise.all([getRewards(), getTransactions(15)]);

  return (
    <div className="space-y-10">
      <div className="card p-6 flex flex-wrap items-center justify-between gap-4 animate-fade-up">
        <div>
          <h1 className="text-2xl font-extrabold">Rewards & Missions</h1>
          <p className="text-white/50 text-sm">Solde actuel : <span className="text-electric font-bold">⚡ {balance.toLocaleString("fr-FR")} pts</span></p>
        </div>
      </div>
      <section>
        <h2 className="text-xl font-bold mb-4">Récompenses disponibles</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rewards.map((r) => (
            <div key={r.id} className="card p-5 flex flex-col gap-3 animate-fade-up">
              <div className="flex items-center justify-between">
                <h3 className="font-bold">{r.title}</h3>
                <span className="badge">+{r.points_reward} pts</span>
              </div>
              <p className="text-sm text-white/55 flex-1">{r.description}</p>
              {r.kind !== "manual" && <ClaimButton rewardId={r.id} title={r.title} />}
              {r.kind === "manual" && <span className="text-xs text-white/40">Attribuée par l'équipe (événements)</span>}
            </div>
          ))}
        </div>
      </section>
      <section>
        <h2 className="text-xl font-bold mb-4">Historique des transactions</h2>
        <div className="card divide-y divide-white/10">
          {transactions.length === 0 && <p className="p-5 text-white/40 text-sm">Aucune transaction.</p>}
          {transactions.map((t) => (
            <div key={t.id} className="p-4 flex items-center justify-between text-sm">
              <div>
                <p>{t.reason}</p>
                <p className="text-xs text-white/35">{new Date(t.created_at).toLocaleString("fr-FR")}</p>
              </div>
              <span className={`font-bold ${t.delta >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                {t.delta >= 0 ? "+" : ""}{t.delta.toLocaleString("fr-FR")}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
