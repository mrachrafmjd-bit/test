"use client";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export default function LogoutButton() {
  const router = useRouter();
  return (
    <button className="text-sm text-white/60 hover:text-white transition"
      onClick={async () => { await createClient().auth.signOut(); router.refresh(); }}>
      Logout
    </button>
  );
}
