"use client";
import { createClient } from "@/lib/supabase/client";

export default function OAuthButtons() {
  const supabase = createClient();
  const signIn = (provider: "google" | "discord") =>
    supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: `${location.origin}/auth/callback` }
    });
  return (
    <div className="flex flex-col gap-3">
      <button onClick={() => signIn("google")} className="btn-primary w-full">Continuer avec Google</button>
      <button onClick={() => signIn("discord")} className="btn-ghost w-full">Continuer avec Discord</button>
      <p className="text-xs text-white/40 text-center">
        Kick : intégration non configurée — voir README §2.3 pour les prérequis OAuth officiels.
        Nous ne demandons jamais votre mot de passe tiers.
      </p>
    </div>
  );
}
