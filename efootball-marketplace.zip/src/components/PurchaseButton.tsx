"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import type { Team } from "@/types/database";

export default function PurchaseButton({ team, balance, owned }: { team: Team; balance: number; owned: boolean }) {
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function purchase() {
    setLoading(true); setMsg(null);
    const { data: { user } } = await createClient().auth.getUser();
    if (!user) { setMsg("Veuillez vous connecter pour acheter."); setLoading(false); return; }
    const { error } = await createClient().rpc("purchase_team", { p_team_id: team.id });
    setLoading(false);
    if (error) {
      setMsg(error.message.includes("INSUFFICIENT_POINTS")
        ? "Points insuffisants — gagnez plus de points dans l'onglet Rewards."
        : error.message.replace(/^[A-Z_]+:?\s*/, ""));
    } else {
      setMsg("✅ Achat réussi ! Retrouvez votre équipe dans My Teams.");
      router.refresh();
    }
  }

  if (owned) return <span className="btn-ghost cursor-default">✓ Dans votre collection</span>;
  const poor = balance < team.price_points;
  return (
    <div className="flex flex-col gap-2">
      <button onClick={purchase} disabled={loading}
        className={`${poor ? "bg-white/10 cursor-not-allowed" : "btn-primary"} rounded-xl px-6 py-3 font-bold transition`}>
        {loading ? "Traitement…" : `Acheter — ⚡ ${team.price_points.toLocaleString("fr-FR")}`}
      </button>
      {poor && <p className="text-sm text-amber-400">Il vous manque {(team.price_points - balance).toLocaleString("fr-FR")} points.</p>}
      {msg && <p className="text-sm text-electric">{msg}</p>}
    </div>
  );
}
