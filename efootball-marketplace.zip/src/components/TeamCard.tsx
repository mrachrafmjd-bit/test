import Image from "next/image";
import Link from "next/link";
import type { Team } from "@/types/database";

export default function TeamCard({ team, owned = false }: { team: Team; owned?: boolean }) {
  return (
    <div className="card animate-fade-up flex flex-col">
      <div className="relative h-36 bg-navy">
        {team.cover_url && <Image src={team.cover_url} alt="" fill className="object-cover opacity-60" sizes="300px" />}
        <div className="absolute inset-0 bg-gradient-to-t from-panel to-transparent" />
        <div className="absolute bottom-3 left-4 flex items-center gap-3">
          {team.logo_url ? (
            <Image src={team.logo_url} alt={team.name} width={44} height={44} className="rounded-full bg-white/90 p-1" />
          ) : (
            <div className="w-11 h-11 rounded-full bg-electric/30 border border-electric flex items-center justify-center font-bold">
              {team.name.slice(0, 2).toUpperCase()}
            </div>
          )}
          <h3 className="font-bold text-lg drop-shadow">{team.name}</h3>
        </div>
        {team.is_featured && <span className="absolute top-3 right-3 badge">★ Featured</span>}
      </div>
      <div className="p-4 flex flex-col gap-2 flex-1">
        <span className="badge w-fit">{team.category}</span>
        <p className="text-sm text-white/60 line-clamp-2 flex-1">{team.description}</p>
        <div className="flex items-center justify-between mt-2">
          <span className="font-extrabold text-electric text-lg">⚡ {team.price_points.toLocaleString("fr-FR")}</span>
          <Link href={`/teams/${team.id}`} className={owned ? "btn-ghost text-sm" : "btn-primary text-sm"}>
            {owned ? "View" : "Details"}
          </Link>
        </div>
      </div>
    </div>
  );
}
