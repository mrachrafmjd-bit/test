import Link from "next/link";
import { getUserContext } from "@/lib/data";
import LogoutButton from "@/components/LogoutButton";

const links = [
  { href: "/", label: "Home" },
  { href: "/marketplace", label: "Marketplace" },
  { href: "/my-teams", label: "My Teams" },
  { href: "/rewards", label: "Rewards" },
  { href: "/profile", label: "Profile" }
];

export default async function Navbar() {
  const { user, profile, balance } = await getUserContext();
  return (
    <header className="sticky top-0 z-50 bg-night/85 backdrop-blur border-b border-white/10">
      <nav className="max-w-7xl mx-auto flex items-center gap-4 px-4 py-3 flex-wrap">
        <Link href="/" className="text-xl font-extrabold tracking-tight">
          <span className="text-electric">e</span>FOOTBALL <span className="text-white/50 text-sm font-medium">MARKET</span>
        </Link>
        <div className="flex gap-1 sm:gap-3 text-sm flex-wrap">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="px-2 py-1 rounded-lg hover:text-electric text-white/80 hover:bg-white/5 transition">
              {l.label}
            </Link>
          ))}
          {profile?.is_admin && (
            <Link href="/admin" className="px-2 py-1 rounded-lg text-amber-400 hover:bg-white/5">Admin</Link>
          )}
        </div>
        <div className="ml-auto flex items-center gap-3">
          {user ? (
            <>
              <span className="badge animate-pulse-glow">⚡ {balance.toLocaleString("fr-FR")} pts</span>
              <span className="hidden sm:block text-sm text-white/70">{profile?.username}</span>
              <LogoutButton />
            </>
          ) : (
            <>
              <Link href="/login" className="btn-ghost text-sm">Login</Link>
              <Link href="/login?mode=register" className="btn-primary text-sm">Register</Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
