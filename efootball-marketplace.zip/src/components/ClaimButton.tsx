"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export default function ClaimButton({ rewardId, title }: { rewardId: string; title: string }) {
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function claim() {
    setLoading(true); setMsg(null);
    const { error } = await createClient().rpc("claim_reward", { p_reward_id: rewardId });
    setLoading(false);
    if (error) setMsg(error.message.replace(/^[A-Z_]+:?\s*/, ""));
    else { setMsg(`✅ +${title} crédité !`); router.refresh(); }
  }
  return (
    <div className="flex items-center gap-2">
      <button onClick={claim} disabled={loading} className="btn-primary text-sm">{loading ? "…" : "Réclamer"}</button>
      {msg && <span className="text-xs text-electric">{msg}</span>}
    </div>
  );
}
