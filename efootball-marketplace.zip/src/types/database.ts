export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export interface Profile {
  id: string; username: string | null; avatar_url: string | null;
  is_admin: boolean; created_at: string;
}
export interface PointsAccount { user_id: string; balance: number; }
export interface Team {
  id: string; name: string; logo_url: string | null; cover_url: string | null;
  description: string | null; category: TeamCategory; price_points: number;
  is_published: boolean; is_featured: boolean; created_at: string;
}
export type TeamCategory =
  | "European Clubs" | "National Teams" | "Legendary Teams" | "Special Teams" | "Exclusive Collections";
export const TEAM_CATEGORIES: TeamCategory[] = [
  "European Clubs", "National Teams", "Legendary Teams", "Special Teams", "Exclusive Collections"
];
export interface OwnedTeam {
  user_id: string; team_id: string; purchased_at: string; price_paid: number;
  teams?: Team;
}
export interface PointTransaction {
  id: string; user_id: string; delta: number; reason: string;
  ref_type: string | null; ref_id: string | null; created_at: string;
}
export interface Reward {
  id: string; title: string; description: string | null;
  points_reward: number; kind: "daily" | "mission" | "manual"; active: boolean;
}
export interface RewardClaim { id: string; user_id: string; reward_id: string; claimed_at: string; }
