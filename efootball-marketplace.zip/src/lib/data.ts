import { createClient } from "@/lib/supabase/server";
import type { Profile, PointsAccount, Team, OwnedTeam, PointTransaction, Reward } from "@/types/database";

export async function getUserContext() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { supabase, user: null, profile: null, balance: 0 };
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single<Profile>();
  const { data: account } = await supabase.from("points_accounts").select("balance").eq("user_id", user.id).single<PointsAccount>();
  return { supabase, user, profile, balance: account?.balance ?? 0 };
}

export async function getTeams(opts?: { category?: string; search?: string; sort?: string; limit?: number }) {
  const supabase = createClient();
  let q = supabase.from("teams").select("*").eq("is_published", true);
  if (opts?.category) q = q.eq("category", opts.category);
  if (opts?.search) q = q.ilike("name", `%${opts.search}%`);
  q = q.order("price_points", { ascending: opts?.sort === "price_desc" ? false : true });
  if (opts?.limit) q = q.limit(opts.limit);
  const { data } = await q;
  return (data ?? []) as Team[];
}

export async function getMyTeams(search?: string) {
  const { supabase, user } = await getUserContext();
  if (!user) return [] as (OwnedTeam & { teams: Team })[];
  let q = supabase.from("owned_teams").select("*, teams(*)").eq("user_id", user.id).order("purchased_at", { ascending: false });
  if (search) q = q.ilike("teams.name", `%${search}%`);
  const { data } = await q;
  return (data ?? []) as (OwnedTeam & { teams: Team })[];
}

export async function getTransactions(limit = 10) {
  const { supabase, user } = await getUserContext();
  if (!user) return [] as PointTransaction[];
  const { data } = await supabase.from("point_transactions").select("*").eq("user_id", user.id)
    .order("created_at", { ascending: false }).limit(limit);
  return (data ?? []) as PointTransaction[];
}

export async function getRewards() {
  const supabase = createClient();
  const { data } = await supabase.from("rewards").select("*").eq("active", true).order("points_reward");
  return (data ?? []) as Reward[];
}
